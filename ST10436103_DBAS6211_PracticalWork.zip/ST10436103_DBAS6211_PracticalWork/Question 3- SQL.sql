CREATE DATABASE ST10436103_Question3;
USE ST10436103_Question3;


-- Q3.1
CREATE TABLE Student (
    StudentID INT AUTO_INCREMENT PRIMARY KEY,
    StudentName VARCHAR(50),
    StudentSurname VARCHAR(50),
    StudentNumber INT
);

-- Q3.2
CREATE TABLE Lecturer (
    LecturerID INT AUTO_INCREMENT PRIMARY KEY,
    LecturerName VARCHAR(100) ,
    LecturerSurname VARCHAR(50)
);

-- Q3.3
CREATE TABLE Tutorial (
    TutorialID INT AUTO_INCREMENT PRIMARY KEY,
    StudentID INT NOT NULL,
    LecturerID INT NOT NULL,
    TutorialDate DATE ,
    TutorialTime TIME,
    TutorialDuration INT ,
    FOREIGN KEY (StudentID) REFERENCES Student(StudentID),
    FOREIGN KEY (LecturerID) REFERENCES Lecturer(LecturerID)
);

-- Q3.4
INSERT INTO Student (StudentName, StudentSurname, StudentNumber) VALUES
('Debbie','Theart', 123456),
('Thomas','Duncan', 654321);

INSERT INTO Lecturer (LecturerName, LecturerSurname) VALUES
('Zintle', 'Nukani'),
('Ravi', 'Maharaj');

INSERT INTO Tutorial (StudentID,LecturerID,TutorialDate, TutorialTime, TutorialDuration) VALUES
(1,2,'2025-01-15', '9:00', 180),
(2,2,'2025-01-18', '15:00', 240),
(1,1,'2025-01-20', '10:00', 180),
(1,2,'2025-01-21', '11:00', 180);

-- Q3.5
SELECT *
FROM Tutorial
WHERE TutorialDate BETWEEN '2025-01-16' AND '2025-01-20';


-- Q3.6
SELECT StudentName, StudentSurname, Count(*) AS numberOf
FROM Tutorial t 
JOIN Student s ON t.StudentID = s.StudentID;
WHERE 


-- Q3.7
CREATE OR REPLACE VIEW 	ViewNames AS
SELECT s.StudentName AS studentName , s.StudentSurname AS StudentSurname
FROM Student s 
JOIN Tutorial rc ON rc.StudentID = r.StudentID
WHERE rc.LecturerID = 2 
 
